// main.js - addon.emet.acestream_links_2

import { addon, catalog, page, modal } from 'emet';

const TV_PATH = 'stream/tv/';

// Definimos las categorías
const categories = [
    { name: 'DAZN LaLiga', file: 'dazn_laliga.json' },
    { name: 'DAZN', file: 'dazn.json' },
    { name: 'LaLiga', file: 'laliga.json' },
    { name: 'Movistar', file: 'movistar.json' },
    { name: 'Liga de Campeones', file: 'liga_de_campeones.json' },
    { name: 'ESPN', file: 'espn.json' },
];

// Función para cargar canales desde JSON
async function loadChannels(jsonFile) {
    try {
        const response = await fetch(`${TV_PATH}${jsonFile}`);
        const data = await response.json();
        return data;
    } catch (err) {
        console.error('Error cargando JSON', jsonFile, err);
        return {};
    }
}

// Función para mostrar canales de una categoría
async function showCategory(category) {
    const channelsObj = await loadChannels(category.file);
    const channelsArray = [];

    // Convertimos el objeto a array
    for (const key in channelsObj) {
        if (channelsObj.hasOwnProperty(key)) {
            channelsObj[key].forEach(ch => {
                channelsArray.push({
                    name: ch.nombre,
                    url: ch.enlace,
                    type: 'acestream', // EMET reconoce ACEStream
                    icon: 'assets/icon.png',
                });
            });
        }
    }

    page.clear(); // limpiamos la página
    page.title(category.name);

    channelsArray.forEach(ch => {
        page.addButton({
            title: ch.name,
            icon: ch.icon,
            onClick: () => playChannel(ch),
        });
    });
}

// Función para reproducir un canal
function playChannel(channel) {
    addon.player.open({
        url: channel.url,
        type: channel.type,
    });
}

// Pantalla principal con categorías
function showMainMenu() {
    page.clear();
    page.title('ACESTREAM LINKS');

    categories.forEach(cat => {
        page.addButton({
            title: cat.name,
            icon: 'assets/icon.png',
            onClick: () => showCategory(cat),
        });
    });
}

// Inicializamos el addon
showMainMenu();
